# 🧠 Mistral-7B LoRA Merge Pipeline

This repository contains the scripts to **merge a LoRA adapter into Mistral-7B-Instruct-v0.2** and publish the merged weights to the Hugging Face Hub.

**Model on HF:** https://huggingface.co/clarkkitchen22/mistral-7b-lora-merged

## Quick Start (Windows / PowerShell)

1) (Optional) Create & activate a venv
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

2) Install deps
```powershell
pip install -r .\requirements.txt
```

3) Merge the adapter
```powershell
python .\merge_lora.py `
  --base "mistralai/Mistral-7B-Instruct-v0.2" `
  --adapter "C:\Users\Clark\my_agent\output\adapter" `
  --out "C:\Users\Clark\my_agent\models\merged" `
  --offload "C:\Users\Clark\my_agent\offload"
```

4) Upload to Hugging Face (after logging in with `hf auth login`)
```powershell
python .\safe_upload.py
```

5) Push this code to GitHub (after creating an empty repo)
```powershell
.\push_to_github.ps1 -RepoUrl "https://github.com/clarkkitchen22/mistral-lora-merge.git"
```

## Files
- `merge_lora.py` — merge a PEFT/LoRA adapter into a base model and save a standalone checkpoint
- `safe_upload.py` — upload all merged files to the Hugging Face Hub
- `push_to_github.ps1` — helper to initialize git and push this folder to your GitHub repo
- `requirements.txt` — Python dependencies
