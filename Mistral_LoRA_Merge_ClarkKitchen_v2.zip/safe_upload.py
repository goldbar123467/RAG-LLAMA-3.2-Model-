import os, time
from pathlib import Path
from huggingface_hub import HfApi, create_repo
from tqdm import tqdm

# Change these if needed
REPO_ID = "clarkkitchen22/mistral-7b-lora-merged"
MODEL_DIR = Path(r"C:\Users\Clark\my_agent\models\merged")

def main():
    api = HfApi()
    create_repo(REPO_ID, private=False, exist_ok=True, repo_type="model")

    all_files = [p for p in MODEL_DIR.rglob("*") if p.is_file()]
    print(f"[i] Found {len(all_files)} files to upload")

    def upload_one(path: Path):
        rel = path.relative_to(MODEL_DIR).as_posix()
        for attempt in range(3):
            try:
                api.upload_file(
                    path_or_fileobj=str(path),
                    path_in_repo=rel,
                    repo_id=REPO_ID,
                    repo_type="model",
                )
                print(f"[ok] Uploaded {rel}")
                return
            except Exception as e:
                print(f"[warn] {rel} attempt {attempt+1} failed: {e}")
                time.sleep(2 * (attempt + 1))

    for f in tqdm(all_files, desc="Uploading files"):
        upload_one(f)

    print("✅ Upload complete:", REPO_ID)

if __name__ == "__main__":
    main()
