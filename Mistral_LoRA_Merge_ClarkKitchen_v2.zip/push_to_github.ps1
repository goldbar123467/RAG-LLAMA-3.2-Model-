param(
  [Parameter(Mandatory=$true)][string]$RepoUrl
)

$ErrorActionPreference = "Stop"

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  Write-Error "git is not installed or not on PATH."
  exit 1
}

Write-Host "[i] Initializing git repo…" -ForegroundColor Cyan
git init

Write-Host "[i] Adding files…" -ForegroundColor Cyan
git add .

Write-Host "[i] Committing…" -ForegroundColor Cyan
git commit -m "Initial commit - Mistral LoRA Merge Project"

Write-Host "[i] Setting main branch…" -ForegroundColor Cyan
git branch -M main

Write-Host "[i] Adding remote…" -ForegroundColor Cyan
git remote add origin $RepoUrl

Write-Host "[i] Pushing to GitHub…" -ForegroundColor Cyan
git push -u origin main

Write-Host "[ok] Done! Repo pushed to $RepoUrl" -ForegroundColor Green
